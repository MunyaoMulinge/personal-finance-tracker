package com.kenyafinance.tracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinanceTrackerApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinanceTrackerApiApplication.class, args);
	}

}
